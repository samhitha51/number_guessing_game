# Simple-Python-Number-Guessing-Game
Pretty Easy to read and understand code with straightforward features

Just Run the exe and play the game. You can play with the code if you want to.

It has two modes, Easy and Hard. Easy mode has infinite turns and Hard Mode has only 5 turns.

Have a Great Day! :)
